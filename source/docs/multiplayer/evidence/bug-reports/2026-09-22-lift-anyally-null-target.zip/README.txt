此问题包由 CombatSolver 设置页导出。
report.json 是问题包身份与筛选元数据；diagnostics 保存环境与文字诊断；replay 保存检查点索引、战斗录制与恢复材料。
当前战斗保存详细记录；离开战斗后仍可提交最近一场，进入下一场后历史战斗只保留摘要。归档保留最近关键的 6 个检查点和完整已记录输入。
CombatSolver 独立日志位于 diagnostics/logs，按大小分片；index.json 标明记录范围、截断或写盘错误。diagnostics/game-logs/godot.log 是游戏全局日志快照；完整日志副本和 Mod 日志同时保存在桌面的 CombatSolver-BugReports/logs。提交时冻结日志前缀，后续战斗不会改变此包。
新包通过 recording 中的真实战前存档与原生动作、选择事件恢复；replay-state 和 native-state 用于独立对账。反射诊断字段存在显式截断时不能作为完整恢复材料。
checkpoint.json v2 列出稳定检查点身份、事件位置、实际搜索政策与材料路径。默认选择最近可搜索检查点；材料检查、恢复、录制回放、搜索和实际部署是不同验证阶段。
forensics/*/pre-combat 保存战前内存跑局快照。截图、整批磁盘存档和更早战斗不会进入问题包。
session.json、检查点和 export-context.json 会标记 controlMode：solver_only 表示全程由求解器接管，manual_plus_solver 表示本场曾手操后再交给求解器；lastSolverDeployedTurn 记录最近一次完整自动执行的回合。
设置页另有独立的“上传问题包”按钮。
